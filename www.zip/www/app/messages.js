angular.module('pele.messages', [])
  .constant("messages", {
    no_cordova: "תכונה זאת  פעילה במכשיר בלבד",
    mail: {
      no_mail_account: "לא הוגדר חשבון אימייל במכשיר זה",
    }
  });